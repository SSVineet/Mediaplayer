/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediaplayer3;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.FileChooser;

/**
 *
 * @author UMANG
 */
public class FXMLDocumentController implements Initializable {
    
    private String filePath;
    private MediaPlayer mediaplayer;
    @FXML
    private Label label;
    @FXML
    private MediaView mediaView;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        FileChooser filechooser = new FileChooser();
        FileChooser.ExtensionFilter filter = new FileChooser.ExtensionFilter("Please ","*.mp4");
        filechooser.getExtensionFilters().add(filter);
        File file = filechooser.showOpenDialog(null);
        filePath = file.toURI().toString();
        if(filePath!=null)
        {
           Media media = new Media(filePath);
           mediaplayer = new MediaPlayer(media);
           mediaView.setMediaPlayer(mediaplayer);
           mediaplayer.play();
        }
        
       
    }
    
    public void pause()
    {
         mediaplayer.pause();
    }
    public void start()
    {
         mediaplayer.play();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
